import pygame
import random
import math
import sys
import asyncio
from pygame import Vector2, Rect

# --- CONFIGURATION ---
pygame.init()
WIDTH, HEIGHT = 1280, 720
ACCENT_COLOR = (0, 255, 200)
BLOOD_RED = (255, 50, 50)
GOLD = (255, 215, 0)
SKY_DARK = (10, 10, 25)
GRAVITY = 0.45
FRICTION = 0.08    
MAX_WALK_SPEED = 4 

async def main():
    # ... other setup ...
    pygame.display.set_caption("National Smurf Piglet.com")

WEAPONS = {
    "GLOCK": {"cooldown": 15, "speed": 20, "ammo": 12, "color": (200, 200, 200), "recoil": 2, "spread": 0},
    "UZI": {"cooldown": 5, "speed": 18, "ammo": 40, "color": (150, 255, 150), "recoil": 4, "spread": 0.1},
    "SNIPER": {"cooldown": 70, "speed": 45, "ammo": 5, "color": (255, 100, 255), "recoil": 15, "spread": 0},
    "SHOTGUN": {"cooldown": 40, "speed": 15, "ammo": 8, "color": (255, 150, 50), "recoil": 10, "spread": 0.3},
}

class Particle:
    def __init__(self, x, y, color, vel=None, life=40):
        self.pos = Vector2(x, y); self.color = color
        self.vel = vel if vel else Vector2(random.uniform(-4, 4), random.uniform(-6, 2))
        self.life = life; self.max_life = life
    def update(self):
        self.vel.y += 0.15; self.pos += self.vel; self.life -= 1
        return self.life > 0
    def draw(self, surf):
        alpha = max(0, int((self.life / self.max_life) * 255))
        p_surf = pygame.Surface((4, 4), pygame.SRCALPHA)
        pygame.draw.circle(p_surf, (*self.color, alpha), (2, 2), random.randint(1, 3))
        surf.blit(p_surf, self.pos)

class Projectile:
    def __init__(self, x, y, angle, owner, stats):
        self.pos = Vector2(x, y); self.owner = owner; self.color = stats["color"]
        actual_angle = angle + random.uniform(-stats["spread"], stats["spread"])
        self.vel = Vector2(math.cos(actual_angle), math.sin(actual_angle)) * stats["speed"]
    def update(self, players, particles):
        self.pos += self.vel
        for p in players:
            if p != self.owner and p.hp > 0 and p.hitbox.collidepoint(self.pos):
                p.hp -= 12; p.vel += self.vel * 0.15 
                for _ in range(12): particles.append(Particle(self.pos.x, self.pos.y, p.color))
                return True
        return not (0 < self.pos.x < WIDTH and 0 < self.pos.y < HEIGHT)
    def draw(self, surf):
        pygame.draw.line(surf, self.color, self.pos, self.pos - (self.vel * 0.5), 3)

class WeaponDrop:
    def __init__(self):
        self.type = random.choice(list(WEAPONS.keys()))
        self.pos = Vector2(random.randint(100, WIDTH-100), -50); self.vel = Vector2(0, 2)
        self.rect = Rect(0, 0, 30, 30)
    def update(self, platforms):
        self.vel.y += 0.1; self.pos += self.vel; self.rect.center = self.pos
        for plat in platforms:
            if self.rect.colliderect(plat) and self.vel.y > 0:
                self.pos.y = plat.top - 15; self.vel.y = 0
        return self.pos.y > HEIGHT + 100
    def draw(self, surf, font):
        color = WEAPONS[self.type]["color"]
        pygame.draw.rect(surf, color, self.rect, 2)

class Player:
    def __init__(self, x, y, color, controls, is_cpu=False):
        self.pos = Vector2(x, y); self.vel = Vector2(0, 0); self.color = color
        self.controls = controls; self.is_cpu = is_cpu; self.hp = 100
        self.facing = 1; self.jumps = 2; self.cooldown = 0
        self.hitbox = Rect(0, 0, 30, 65); self.walk_cycle = 0
        self.weapon = None; self.ammo = 0
        self.punching = 0 

    def update(self, platforms, target, projectiles, weapons, particles):
        if self.hp <= 0: return
        
        if not self.is_cpu:
            keys = pygame.key.get_pressed()
            if keys[self.controls['left']]: self.vel.x -= 0.3; self.facing = -1
            elif keys[self.controls['right']]: self.vel.x += 0.3; self.facing = 1
            else: self.vel.x *= (1 - FRICTION)
            
            if keys[self.controls['jump']] and self.jumps > 0:
                if not hasattr(self, 'jump_held') or not self.jump_held:
                    self.vel.y = -10; self.jumps -= 1; self.jump_held = True
            else: self.jump_held = False

            if keys[self.controls['fire']]:
                if self.weapon: self.shoot(projectiles)
                else: self.punch(target, particles)
        else:
            dist = target.pos.x - self.pos.x
            follow_dist = 40 if not self.weapon else 250
            if abs(dist) > follow_dist:
                self.vel.x += 0.2 if dist > 0 else -0.2; self.facing = 1 if dist > 0 else -1
            if self.cooldown <= 0:
                if not self.weapon and abs(dist) < 50: self.punch(target, particles)
                elif self.weapon and abs(target.pos.y - self.pos.y) < 200: self.shoot(projectiles)
            if random.random() < 0.005 and self.jumps > 0: self.vel.y = -10; self.jumps -= 1

        self.vel.y += GRAVITY
        if abs(self.vel.x) > MAX_WALK_SPEED: self.vel.x = MAX_WALK_SPEED if self.vel.x > 0 else -MAX_WALK_SPEED
        self.pos += self.vel; self.pos.x = max(20, min(WIDTH-20, self.pos.x))
        self.hitbox.midbottom = self.pos

        on_ground = False
        for plat in platforms:
            if self.hitbox.colliderect(plat) and self.vel.y > 0:
                if self.pos.y - self.vel.y <= plat.top + 5:
                    self.hitbox.bottom = plat.top; self.pos.y = self.hitbox.bottom
                    self.vel.y = 0; self.jumps = 2; on_ground = True

        for w in weapons[:]:
            if self.hitbox.colliderect(w.rect):
                self.weapon = w.type; self.ammo = WEAPONS[w.type]["ammo"]; weapons.remove(w)

        if on_ground and abs(self.vel.x) > 0.5: self.walk_cycle += 0.1
        if self.cooldown > 0: self.cooldown -= 1
        if self.punching > 0: self.punching -= 1

    def punch(self, target, particles):
        if self.cooldown > 0: return
        self.punching = 10; self.cooldown = 20
        punch_rect = Rect(0, 0, 45, 40)
        if self.facing == 1: punch_rect.midleft = self.hitbox.midright
        else: punch_rect.midright = self.hitbox.midleft
        if punch_rect.colliderect(target.hitbox):
            target.hp -= 8; target.vel += Vector2(8 * self.facing, -3)
            for _ in range(5): particles.append(Particle(target.pos.x, target.pos.y-40, target.color))

    def shoot(self, projectiles):
        if self.cooldown > 0 or not self.weapon: return
        stats = WEAPONS[self.weapon]
        angle = 0 if self.facing == 1 else math.pi
        count = 5 if self.weapon == "SHOTGUN" else 1
        for _ in range(count): projectiles.append(Projectile(self.pos.x, self.pos.y - 40, angle, self, stats))
        self.vel.x -= stats["recoil"] * 0.7 * self.facing
        self.cooldown = stats["cooldown"]; self.ammo -= 1
        if self.ammo <= 0: self.weapon = None

    def draw(self, surf, font):
        if self.hp <= 0: return
        x, y = int(self.pos.x), int(self.pos.y)
        pygame.draw.rect(surf, (50, 0, 0), (x-25, y-90, 50, 6))
        pygame.draw.rect(surf, self.color, (x-25, y-90, int(50 * (self.hp/100)), 6))
        head_y = y - 55
        pygame.draw.circle(surf, self.color, (x, head_y), 10, 2)
        pygame.draw.line(surf, self.color, (x, head_y + 10), (x, y - 20), 2)
        swing = math.sin(self.walk_cycle) * 15
        pygame.draw.line(surf, self.color, (x, y-20), (x + swing, y), 2)
        pygame.draw.line(surf, self.color, (x, y-20), (x - swing, y), 2)
        arm_start = (x, y-40)
        if self.punching > 0:
            arm_end = (x + (40 * self.facing), y - 40)
            pygame.draw.line(surf, (255, 255, 255), arm_start, arm_end, 4)
        else:
            arm_end = (x + (25 * self.facing), y - 35)
            pygame.draw.line(surf, self.color, arm_start, arm_end, 3)
        if self.weapon:
            txt = font.render(f"{self.weapon}: {self.ammo}", True, GOLD)
            surf.blit(txt, (x-20, y-110))

async def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Cyber Stick Fighter: Melee Edition")
    clock = pygame.time.Clock()
    
    font_small = pygame.font.SysFont("Arial", 18)
    font_main = pygame.font.SysFont("Arial", 48, bold=True)
    
    platforms = [Rect(100, 550, 1080, 20), Rect(200, 400, 300, 20), Rect(780, 400, 300, 20)]
    
    p1_controls = {'left': pygame.K_a, 'right': pygame.K_d, 'jump': pygame.K_w, 'fire': pygame.K_SPACE}
    p2_controls = {'left': pygame.K_LEFT, 'right': pygame.K_RIGHT, 'jump': pygame.K_UP, 'fire': pygame.K_m}
    
    player1 = Player(300, 500, ACCENT_COLOR, p1_controls)
    player2 = Player(900, 500, BLOOD_RED, p2_controls, is_cpu=True)
    
    projectiles = []
    particles = []
    weapons = []
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Random weapon spawns
        if random.random() < 0.01:
            weapons.append(WeaponDrop())

        # Update
        player1.update(platforms, player2, projectiles, weapons, particles)
        player2.update(platforms, player1, projectiles, weapons, particles)
        
        projectiles = [p for p in projectiles if not p.update([player1, player2], particles)]
        particles = [p for p in particles if p.update()]
        weapons = [w for w in weapons if not w.update(platforms)]

        # Draw
        screen.fill(SKY_DARK)
        for plat in platforms:
            pygame.draw.rect(screen, (40, 40, 60), plat)
        
        for w in weapons: w.draw(screen, font_small)
        for p in projectiles: p.draw(screen)
        for p in particles: p.draw(screen)
        
        player1.draw(screen, font_small)
        player2.draw(screen, font_small)

        if player1.hp <= 0 or player2.hp <= 0:
            msg = "PLAYER 1 WINS!" if player2.hp <= 0 else "CPU WINS!"
            txt = font_main.render(msg, True, GOLD)
            screen.blit(txt, (WIDTH//2 - 150, HEIGHT//2))

        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(60)

if __name__ == "__main__":
    asyncio.run(main())
